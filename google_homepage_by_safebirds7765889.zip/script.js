// You can add some JavaScript here for additional functionality
console.log('Google homepage script loaded');

import * as THREE from 'three';

let room;
 
const cursors = {};
 
async function init() {
  room = new WebsimSocket();
  await room.initialize();
 
  room.subscribePresence((currentPresence) => {
   // NOTE: `room.presence` is already kept up to date before this callback is called.
   // This is more for game-specific side effects.
   updateCursors(currentPresence);
  });
 
  // Initial cursor setup
  updateCursors(room.presence);
 
  document.addEventListener('mousemove', (event) => {
   const x = event.clientX;
   const y = event.clientY;
   room.updatePresence({ x, y });
  });
}
 
function updateCursors(presence) {
  // Clear existing cursors
  for (const clientId in cursors) {
   if (!presence[clientId]) {
    document.body.removeChild(cursors[clientId].element);
    document.body.removeChild(cursors[clientId].nameTag);
    delete cursors[clientId];
   }
  }
 
  // Update or create cursors
  for (const clientId in presence) {
   const client = presence[clientId];
   if (!cursors[clientId]) {
    // Create cursor element
    const cursorElement = document.createElement('div');
    cursorElement.style.position = 'absolute';
    cursorElement.style.width = '20px';
    cursorElement.style.height = '20px';
    cursorElement.style.borderRadius = '50%';
    cursorElement.style.backgroundColor = 'rgba(0, 0, 255, 0.5)'; // Blue cursor
    cursorElement.style.pointerEvents = 'none'; // Prevent cursor from interfering with page interactions
    document.body.appendChild(cursorElement);
 
    // Create name tag
    const nameTag = document.createElement('div');
    nameTag.style.position = 'absolute';
    nameTag.style.color = 'black';
    nameTag.style.fontSize = '12px';
    nameTag.style.fontFamily = 'Arial, sans-serif';
    nameTag.style.pointerEvents = 'none';
    document.body.appendChild(nameTag);
 
    cursors[clientId] = {
     element: cursorElement,
     nameTag: nameTag,
    };
   }
 
   // Update cursor position and name tag
   cursors[clientId].element.style.left = `${client.x}px`;
   cursors[clientId].element.style.top = `${client.y}px`;
   cursors[clientId].nameTag.style.left = `${client.x}px`;
   cursors[clientId].nameTag.style.top = `${client.y + 20}px`; // Position name tag below cursor
   cursors[clientId].nameTag.textContent = room.peers[clientId].username;
  }
}
 
init();